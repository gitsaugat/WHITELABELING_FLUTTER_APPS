class Urls {
  static const String Token = "https://api.editricetoni.it/user/token_info/";
  static const String QuizList = "https://api.editricetoni.it/user/quiz_list/";
  static const String Categories =
      "https://api.editricetoni.it/quiz/category_hierarchy/";
  static const String Media = "https://api.editricetoni.it/medias/";
}
