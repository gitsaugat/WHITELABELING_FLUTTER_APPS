class QuizListItem {
  final int id;
  final String title;
  QuizListItem({this.id, this.title});
}
