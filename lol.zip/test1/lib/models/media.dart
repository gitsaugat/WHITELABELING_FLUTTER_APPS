class MediaItem {
  final int id;
  final String title;
  final String ext;
  final String file;
  final double percentage;
  MediaItem({this.id, this.title, this.ext, this.file, this.percentage});
}
